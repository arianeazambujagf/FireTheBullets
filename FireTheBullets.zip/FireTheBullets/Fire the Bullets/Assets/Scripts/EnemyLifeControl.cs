﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyLifeControl : MonoBehaviour {

    public EnemyType enemyType;
    private int life;
    public float speed = 10f;

    private Rigidbody rb;

    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody>();

        switch (enemyType)
        {
            case EnemyType.Lvl1Enemy:
                {           
                    life = 5;
                }
                break;
            case EnemyType.Lvl2Enemy:
                {
                    life = 10;
                }
                break;
           
        }
    }
	
   public void LifeDecreases()
    {
        life--;

        if (life <= 0)
            Destroy(gameObject);
    }

	
}
