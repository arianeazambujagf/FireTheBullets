﻿public enum EnemyType
{
    Lvl1Enemy,
    Lvl2Enemy
}
